var usrPwd="88888";
var usrNm="Samiran";


// function func(){
//     var myInput=document.getElementById("pwd").value;
//     var usrPwd="88888";
//     if(usrPwd===myInput){
        
//         document.getElementById("showText").innerHTML="<b style='color:green'>pwd is correct</b>";
       
//         window.location.replace("http://stackoverflow.com");

//     }else{
//         document.getElementById("showText").innerHTML="<b style='color:red'>pwd is correct</b>";
//     }
// }


// function redir(){
// var myInput=document.getElementById("pwd").value;
// var usrPwd="samiran";
// if(usrPwd==myInput){
// //document.getElementById("showText").innerHTML="password is correct";
// window.location.replace("http://stackoverflow.com");
// }else{
//     document.getElementById("showText").innerHTML="password is in correct";
// }

// }
var inp=document.getElementById("inp");
var button=document.getElementById("button");

$(document).ready(function(){
   
    $("#button").click(function(){
if(inp.type=="password"){
    inp.setAttribute("type","text");
button.innerText="hide";
}else{
    inp.setAttribute("type","password")
    button.innerText="show";
}
     
    });
  });


//   button.onclick=()=>{

//         if(text.className=="show"){
//             text.className="";
//             button.innerText="Read More";
            
    
//         }else{
//             text.className="show";
            
//             button.innerText="Read Less";
//         }
    
    
    
//     }
    